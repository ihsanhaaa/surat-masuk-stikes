<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © Sekolah Tinggi Kesehatan Sambas | Made By <a href="" target="_blank"> <i class="fas fa-heart"></i> </a>.
            </div>
        </div>
    </div>
</footer>