<!DOCTYPE html>
<html>
<head>
    <title>Password Changed</title>
</head>
<body>
    <p>Your password has been changed sipatri.</p>
    <p>Email: {{ $email }}</p>
    <p>Password: {{ $password }}</p>
</body>
</html>
